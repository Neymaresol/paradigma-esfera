from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from uuid import uuid4
from datetime import datetime, timezone

app = FastAPI(title='PARADIGMA ESFERA 1.0', version='1.0.0-dev')
CATALOG = [
 {'id':'ia-basica','name':'IA no dia a dia','category':'Cursos','price_brl':9.90,'duration_min':30},
 {'id':'celular','name':'Celular e aplicativos','category':'Cursos','price_brl':9.90,'duration_min':30},
 {'id':'seguranca','name':'Segurança digital','category':'Cursos','price_brl':9.90,'duration_min':30},
 {'id':'planilhas','name':'Planilhas para trabalho','category':'Cursos','price_brl':14.90,'duration_min':45},
 {'id':'vendas','name':'Vendas digitais','category':'Cursos','price_brl':14.90,'duration_min':45},
 {'id':'marketing','name':'Divulgação responsável','category':'Cursos','price_brl':14.90,'duration_min':45},
 {'id':'curriculo','name':'Currículo profissional','category':'Serviços','price_brl':9.90},
 {'id':'catalogo','name':'Catálogo digital','category':'Serviços','price_brl':29.90},
 {'id':'agenda','name':'Agenda inteligente','category':'Serviços','price_brl':14.90},
 {'id':'atendimento','name':'Atendimento com IA','category':'Serviços','price_brl':19.90},
]
# In-memory simulation only; never stores real customer data or processes payments.
ORDERS = {}
class SimulatedOrder(BaseModel):
    product_id: str
    country: str = Field(default='BR', pattern='^(BR|PT|ES|US)$')
@app.get('/health')
def health():
    return {'status':'ok','service':'paradigma-esfera','version':'1.0.0-dev','mode':'simulation','checkout_enabled':False,'live_ads_enabled':False,'auto_replication_enabled':False}
@app.get('/api/catalog')
def catalog():
    return {'currency':'BRL','prices_are_suggested':True,'items':CATALOG}
@app.post('/api/orders/simulate')
def simulate(order:SimulatedOrder):
    item=next((p for p in CATALOG if p['id']==order.product_id),None)
    if not item: raise HTTPException(404,'Produto não encontrado')
    oid=str(uuid4()); data={'id':oid,'product_id':item['id'],'country':order.country,'status':'SIMULATED_ONLY','payment_confirmed':False,'commission_confirmed':False,'created_at':datetime.now(timezone.utc).isoformat()}
    ORDERS[oid]=data
    return data
@app.get('/api/orders/{order_id}')
def order_status(order_id:str):
    if order_id not in ORDERS: raise HTTPException(404,'Pedido não encontrado')
    return ORDERS[order_id]
@app.get('/',response_class=HTMLResponse)
def home():
    cards=''.join(f'<article><span>{p["category"]}</span><h3>{p["name"]}</h3><strong>R$ {p["price_brl"]:.2f}</strong><p>Oferta em preparação · contratação indisponível</p></article>' for p in CATALOG)
    return f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PARADIGMA ESFERA 1.0</title><style>body{{margin:0;background:#071226;color:#eaf5ff;font:16px system-ui}}header{{padding:48px 6%;background:radial-gradient(circle at 70% 30%,#154e8d,#071226 55%)}}h1{{font-size:clamp(30px,5vw,60px);margin:12px 0}}p{{color:#a9bdd2}}.tag{{color:#67e8f9;letter-spacing:3px}}main{{padding:28px 6%}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px}}article{{background:#10253e;border:1px solid #244565;border-radius:18px;padding:22px}}article span{{color:#67e8f9;font-size:12px}}strong{{font-size:24px}}.notice{{padding:12px;border:1px solid #51718b;border-radius:12px}}</style></head><body><header><div class="tag">PARADIGMA · EDUCAÇÃO & SERVIÇOS</div><h1>Uma esfera de soluções.<br>Infinitas formas de aprender.</h1><p>Aprenda habilidades digitais e descubra serviços acessíveis.</p><p class="notice">Protótipo de demonstração. Não aceita pagamentos nem realiza divulgação automática.</p></header><main><h2>Primeiras células comerciais</h2><div class="grid">{cards}</div><p>Brasil primeiro · arquitetura preparada para internacionalização · versão 1.0.0-dev</p></main></body></html>'''

from esfera_engine import Gate, expansion_decision, campaign_plan

class ExpansionRequest(BaseModel):
    verified_sales: int = Field(default=0, ge=0)
    verified_margin_brl: float = 0
    fulfilled_orders: int = Field(default=0, ge=0)
    unresolved_incidents: int = Field(default=0, ge=0)
    approved_budget_brl: float = Field(default=0, ge=0)
    platform_authorized: bool = False
    owner_approved: bool = False
    health_ok: bool = False
    proposed_children: int = Field(default=10, ge=1, le=10)

@app.post('/api/expansion/evaluate')
def evaluate_expansion(req: ExpansionRequest):
    values = req.model_dump()
    proposed_children = values.pop('proposed_children')
    # Caller supplied values are NOT trusted evidence. Never allow provisioning from this endpoint.
    result = expansion_decision(Gate(**values), proposed_children)
    result['evidence_verified_by_server'] = False
    result['deployment_allowed'] = False
    return result

@app.get('/api/campaigns/drafts')
def campaign_drafts(channel: str = 'facebook'):
    if channel not in ('facebook', 'instagram', 'tiktok', 'search'):
        raise HTTPException(400, 'Canal não permitido')
    return {'campaigns': [campaign_plan(p, channel) for p in CATALOG],
            'publication_enabled': False, 'advertising_spend_enabled': False}
